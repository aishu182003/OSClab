const fs = require("fs");

const data = "Hello! My name is Aishu";

fs.writeFile("sample.txt", data, (err) => {
  if (err) {
    console.log("Error writing file:", err);
  } else {
    console.log("File created successfully!");

    fs.readFile("sample.txt", "utf8", (err, content) => {
      if (err) {
        console.log("Error reading file:", err);
      } else {
        console.log("File Contents:");
        console.log(content);
      }
    });
  }
});